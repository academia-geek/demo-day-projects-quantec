import styled from 'styled-components';

export const Contenedor = styled.div`
    background-color: white;
    padding: 0px;
    justify-content: center;
    align-items: center;
   height:672px;
    
    
    `
export const Nombre = styled.h2`
   
    margin:0;
    padding:0;
    font-family: 'Montserrat';
font-style: normal;
font-weight: 1000;
font-size: 24px;
line-height: 29px;
letter-spacing: -0.3px;

color: #2F2E41;
margin-bottom:8px;
`
export const ImageProfile = styled.img`
margin-top:17%;
margin-bottom:4.27%;
    width: 36.267%;
    border-radius: 50%;
    ;
`
