import React from 'react'

const OpenedTips = () => {
    return (
        <div>OpenedTips</div>
    )
}

export default OpenedTips