import React from 'react'

const InfoAimsNone = () => {
  return (
    <div>
        <h2>Aun no tienes ningun objetivo</h2>
        <img src="https://res.cloudinary.com/dn1jeryp3/image/upload/v1648132063/proyecto-final/Pig_2_ywta35.svg" alt="" />
    </div>
  )
}

export default InfoAimsNone